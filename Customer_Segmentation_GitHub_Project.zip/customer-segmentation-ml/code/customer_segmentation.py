# Customer Segmentation Project
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

df = pd.read_csv("customer_segmentation_dataset.csv")

# RFM-style behavioral features
features = ["Recency_Days", "Total_Orders", "Total_Spend_INR"]
X = StandardScaler().fit_transform(df[features])

# Compare K values
scores = {}
for k in range(2, 7):
    model = KMeans(n_clusters=k, random_state=42, n_init=20)
    labels = model.fit_predict(X)
    scores[k] = silhouette_score(X, labels)

print("Silhouette scores:", scores)

# Four clusters are selected for actionable business segmentation.
k = 4
model = KMeans(n_clusters=k, random_state=42, n_init=20)
df["Cluster"] = model.fit_predict(X)

print("Final silhouette score:", silhouette_score(X, df["Cluster"]))
print(df.groupby("Cluster")[features].mean().round(2))

df.to_csv("customer_segmentation_results.csv", index=False)
