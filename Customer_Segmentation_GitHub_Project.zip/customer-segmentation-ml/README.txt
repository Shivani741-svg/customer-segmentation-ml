# Customer Segmentation Internship Project

## Files
- Customer_Segmentation_Internship_Project_Report.docx — detailed report
- customer_segmentation_dataset.csv — project input dataset (300 records)
- customer_segmentation_results.csv — dataset with cluster and segment
- segment_summary.csv — segment-level summary
- code/customer_segmentation.py — core Python implementation
- charts/ — generated visualizations

## How to run
1. Install Python 3.x.
2. Install packages:
   pip install pandas numpy scikit-learn matplotlib
3. Put the Python file in the same folder as the input CSV.
4. Run:
   python customer_segmentation.py

## Important academic note
The dataset is synthetic for demonstration. In an internship submission, describe it as a sample/demo dataset unless your internship company provided an actual dataset.
