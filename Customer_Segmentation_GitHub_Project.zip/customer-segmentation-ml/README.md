# Customer Segmentation Using Machine Learning

A BTech CSE internship project that groups customers based on purchasing behavior using Python and K-Means clustering.

## Project overview
This project analyzes customer recency, order frequency, and total spending to identify meaningful customer groups. It includes a sample dataset, Python implementation, result files, visualizations, and a detailed report.

## Objectives
- Explore customer demographics and purchasing behavior.
- Prepare and standardize numerical data.
- Apply K-Means clustering.
- Compare cluster counts using silhouette scores.
- Interpret customer groups and suggest targeted marketing actions.

## Technologies
- Python
- Pandas and NumPy
- Scikit-learn
- Matplotlib
- CSV dataset

## Dataset
`customer_segmentation_dataset.csv` contains 300 **synthetic/demo customer records**. It is not real company or personal customer data.

Important columns:
- `Recency_Days`: days since last purchase
- `Total_Orders`: total number of orders
- `Total_Spend_INR`: total customer spending
- `Annual_Income_INR`: annual income (INR)
- `Satisfaction_Score`: satisfaction score from 1 to 5

## How to run
1. Install Python 3.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Keep `customer_segmentation_dataset.csv` and `customer_segmentation.py` in the same folder.
4. Run:
   ```bash
   python customer_segmentation.py
   ```

## Main project files
- `Customer_Segmentation_Internship_Project_Report.docx` — detailed report
- `customer_segmentation_dataset.csv` — input sample data
- `customer_segmentation_results.csv` — customer records with cluster assignments
- `segment_summary.csv` — summary of customer segments
- `code/customer_segmentation.py` — Python implementation
- `charts/` — visualizations generated for the report

## Business use
The identified groups can support VIP retention, loyalty rewards, cross-selling, re-engagement campaigns, and targeted offers. Segment names are business interpretations of the clustering output.

## Limitations
The data is synthetic and used for demonstration. Results on real business data may differ. Cluster count, selected features, and data quality influence the output.

## Author
Sachin Pal — B.Tech Computer Science & Engineering
